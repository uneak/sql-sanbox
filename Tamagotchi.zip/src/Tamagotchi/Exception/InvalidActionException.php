<?php

    namespace App\Tamagotchi\Exception;

    class InvalidActionException extends ActionException
    {
    }