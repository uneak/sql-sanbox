<?php

    namespace App\Tamagotchi\Exception;

    class ActionException extends \Exception
    {
    }