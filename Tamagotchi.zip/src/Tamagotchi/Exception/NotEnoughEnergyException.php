<?php

    namespace App\Tamagotchi\Exception;

    class NotEnoughEnergyException extends ActionException
    {
    }