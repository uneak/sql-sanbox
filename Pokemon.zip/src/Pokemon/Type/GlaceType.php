<?php

    namespace App\Pokemon\Type;

    use App\Pokemon\Type;

    readonly class GlaceType extends Type
    {
        public function __construct() {
            parent::__construct("Glace");
        }
    }