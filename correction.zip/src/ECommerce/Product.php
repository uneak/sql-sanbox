<?php

    namespace App\ECommerce;

    use App\ECommerce\Exception\InvalidProductException;

    class Product
    {
        private string $name;
        private int $stock;
        private float $price;

        public function __construct(string $name, int $stock, float $price)
        {
            $this->name = $name;
            $this->stock = $stock;
            $this->price = $price;
        }

        public function isAvailable(): bool
        {
            return $this->stock > 0;
        }

        /**
         * @throws InvalidProductException
         */
        public function purchase(): void
        {
            if (!$this->isAvailable()) {
                throw new InvalidProductException(
                    sprintf('Product %s is not available', $this->name),
                );
            }

            $this->stock--;
        }

        public function getPrice(): float
        {
            return $this->price;
        }

        public function getName(): string
        {
            return $this->name;
        }

    }