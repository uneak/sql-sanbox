<?php

    namespace App\ECommerce\Exception;

    class PurchaseException extends \Exception
    {
    }