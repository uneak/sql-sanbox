<?php

    namespace App\ECommerce\Exception;

    class OutOfStockException extends PurchaseException
    {

    }