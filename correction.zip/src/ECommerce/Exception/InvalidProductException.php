<?php

    namespace App\ECommerce\Exception;

    class InvalidProductException extends \Exception
    {
    }