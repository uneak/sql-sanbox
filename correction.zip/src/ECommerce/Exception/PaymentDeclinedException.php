<?php

    namespace App\ECommerce\Exception;

    class PaymentDeclinedException extends PurchaseException
    {

    }