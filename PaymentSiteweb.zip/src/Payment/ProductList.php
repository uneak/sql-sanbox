<?php

    namespace App\Payment;

    class ProductList
    {
        /**
         * @var array<\App\Payment\Product>
         */
        public array $products = [];

        public function __construct()
        {
            $souris = new Product(
                1,
                'Souris',
                10,
                "/shop/img/images.jpeg",
            );

            $clavier = new Product(
                2,
                'Clavier',
                20,
                "/shop/img/images (1).jpeg",
            );

            $ecran = new Product(
                3,
                'Ecran',
                100,
                "/shop/img/images (2).jpeg",
            );

            $pc = new Product(
                4,
                'PC',
                500,
                "/shop/img/images (3).jpeg",
            );

            $telephone = new Product(
                5,
                'Téléphone',
                200,
                "/shop/img/images (4).jpeg",
            );

            $this->products = [$souris, $clavier, $ecran, $pc, $telephone];
        }

        public function getProductById(int $id): ?Product
        {
            foreach ($this->products as $product) {
                if ($product->getId() === $id) {
                    return $product;
                }
            }

            return null;
        }
    }