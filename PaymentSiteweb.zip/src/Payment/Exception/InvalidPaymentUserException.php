<?php

    namespace App\Payment\Exception;

    class InvalidPaymentUserException extends InvalidPaymentException
    {
    }