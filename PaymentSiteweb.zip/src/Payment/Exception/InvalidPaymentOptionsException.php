<?php

    namespace App\Payment\Exception;

    class InvalidPaymentOptionsException extends InvalidPaymentException
    {
    }