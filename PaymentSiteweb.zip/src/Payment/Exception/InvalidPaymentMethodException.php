<?php

    namespace App\Payment\Exception;

    class InvalidPaymentMethodException extends InvalidPaymentException
    {
    }