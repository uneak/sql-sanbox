<?php

    namespace App\Payment\Exception;

    class InvalidPaymentException extends \Exception
    {
    }