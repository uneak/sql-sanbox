<?php

    namespace App\Payment;

    class Product
    {
        private int $id;
        private string $name;
        private float $price;
        private string|null $photo;

        public function __construct(
            int $id,
            string $name,
            float $price,
            string|null $photo,
        ) {
            $this->id = $id;
            $this->name = $name;
            $this->price = $price;
            $this->photo = $photo;
        }

        public function getId(): int
        {
            return $this->id;
        }

        public function getName(): string
        {
            return $this->name;
        }

        public function getPrice(): float
        {
            return $this->price;
        }

        public function getPhoto(): ?string
        {
            return $this->photo;
        }

    }