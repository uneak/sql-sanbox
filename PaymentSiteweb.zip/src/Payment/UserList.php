<?php

    namespace App\Payment;

    class UserList
    {
        /**
         * @var array<\App\Payment\User>
         */
        public array $users = [];

        public function __construct()
        {
            $marc = new User(
                1,
                'Marc',
                'Galoyer',
                null,
                'admin',
                "0690684020",
                "mgaloyer@uneak.fr",
                "123456"
            );

            $drucila = new User(
                2,
                'Drucila',
                'Larochelle',
                null,
                'member',
                "0690684020",
                "drucila@email.com",
                "123456"
            );

            $marieHelene = new User(
                3,
                'Marie-Hélène',
                'Basse',
                null,
                'member',
                "0690684020",
                "mh@email.com",
                "123456"
            );

            $gary = new User(
                4,
                'Gary',
                'Doe',
                null,
                'admin',
                '0690123456',
                'gary@uneak.fr',
                '123456'
            );

            $agnes = new User(
                5,
                'Agnes',
                'Mathey',
                null,
                'admin',
                '0690123456',
                'agnes@uneak.fr',
                '123456'
            );

            $this->users = [$marc, $drucila, $marieHelene, $gary, $agnes];
        }

        public function getUserById(int $id): ?User
        {
            foreach ($this->users as $user) {
                if ($user->getId() === $id) {
                    return $user;
                }
            }

            return null;
        }
    }