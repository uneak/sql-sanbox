<?php

    namespace App\Payment\Options;

    interface PaymentOptionsInterface
    {
    }