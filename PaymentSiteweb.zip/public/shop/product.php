<?php
    require __DIR__ . '/../../vendor/autoload.php';

    use App\Payment\Method\BankTransferPayment;
    use App\Payment\Method\BitcoinPayment;
    use App\Payment\Method\CreditCardPayment;
    use App\Payment\Method\PayPalPayment;
    use App\Payment\Options\BankTransfertOptions;
    use App\Payment\Options\BitcoinOptions;
    use App\Payment\Options\CreditCardOptions;
    use App\Payment\Options\PaypalOptions;
    use App\Payment\Payment;
    use App\Payment\PaymentMethodFactory;
    use App\Payment\ProductList;
    use App\Payment\UserList;
    use App\Payment\UserPaymentOptions;
    use App\Payment\UserPaymentOptionsFactory;

    $userList = new UserList();
    $productList = new ProductList();


    if (!isset($_GET["user"])) {
        header("Location: index.php");
        exit;
    }

    if (!isset($_GET["product"])) {
        header("Location: home.php?user={$_GET["user"]}");
        exit;
    }

    $user = $userList->getUserById($_GET["user"]);
    $product = $productList->getProductById($_GET["product"]);

    $paymentMethodFactory = new PaymentMethodFactory([
        'credit_card'   => new CreditCardPayment(),
        'paypal'        => new PayPalPayment(),
        'bank_transfer' => new BankTransferPayment(),
        'bitcoin'       => new BitcoinPayment(),
    ]);

    $methodList = $paymentMethodFactory->getPaymentMethods();




    if (isset($_POST["user"]) && isset($_POST["product"]) && isset($_POST["method"])) {

		$paymentOptions = [];
        foreach ($userList->users as $listUser) {
            $userPaymentOptions = new UserPaymentOptions($listUser);
            $userPaymentOptions->addPaymentOptions('credit_card', new CreditCardOptions(
                '1234 5678 9012 3456',
                '12/25',
                '123'
            ));

            $userPaymentOptions->addPaymentOptions('paypal', new PaypalOptions(
                'marc@example.com',
                'password'
            ));
            $userPaymentOptions->addPaymentOptions('bank_transfer', new BankTransfertOptions(
                'FR7630004000031234567890143',
                'BNPAFRPPXXX'
            ));
            $userPaymentOptions->addPaymentOptions('bitcoin', new BitcoinOptions(
                '1BoatSLRHtKNngkdXEeobR76b53LETtpyT'
            ));

            $paymentOptions[] = $userPaymentOptions;
        }

        $userPaymentOptionsFactory = new UserPaymentOptionsFactory($paymentOptions);

        $payment = new Payment($paymentMethodFactory, $userPaymentOptionsFactory);


        $payment->pay($userList->getUserById($_POST["user"]), $_POST["method"],  $productList->getProductById($_POST["product"])->getPrice());

    }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Page HTML Classique</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
		  integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
<header>
	<div class="container">
		<h1>Bienvenue <?php echo $user->getFirstName() . " " . $user->getLastName(); ?></h1>
		<p>Une simple page HTML pour commencer</p>
	</div>
</header>
<main>
	<div class="container mt-4">
		<div class="row">
			<form action="/shop/product.php?user=<?php echo $_GET["user"]; ?>&product=<?php echo $_GET["product"]; ?>" method="post">
				<div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary"
					 style="background-image: url('<?php echo $product->getPhoto(); ?>'); background-size: cover;">
					<div class="col-md-6 p-lg-5 mx-auto my-5">
						<h1 class="display-3 fw-bold"><?php echo $product->getName(); ?></h1>
						<h3 class="fw-normal text-muted mb-3">Price: <?php echo $product->getPrice(); ?> €</h3>
						<select name="method" class="form-select form-select-lg mb-3" aria-label="Large select example">
							<option selected>Method de payment</option>
                            <?php
                                foreach ($methodList as $key => $method) {
                                    echo "<option value=\"{$key}\">{$method->getName()}</li>";
                                }
                            ?>
						</select>
						<div class="d-flex gap-3 justify-content-center lead fw-normal">
							<input name="user" type="hidden" value="<?php echo $_GET["user"]; ?>">
							<input name="product" type="hidden" value="<?php echo $_GET["product"]; ?>">
							<button type="submit" class="btn btn-primary">Buy</button>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</main>

<footer class="text-center mt-4">
	<p>&copy; 2024 Votre Nom</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
		crossorigin="anonymous"></script>
</body>
</html>
