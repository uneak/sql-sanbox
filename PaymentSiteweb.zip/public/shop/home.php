<?php
    require __DIR__ . '/../../vendor/autoload.php';

    use App\Payment\ProductList;
    use App\Payment\UserList;


    $userList = new UserList();
    $productList = new ProductList();


	if (!isset($_GET["user"])) {
        header("Location: index.php");
        exit;
	}

	$currentUser = $_GET["user"];
	$user = $userList->getUserById($currentUser);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Page HTML Classique</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
		  integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
<header>
	<div class="container">
		<h1>Bienvenue <?php echo $user->getFirstName() . " " . $user->getLastName(); ?></h1>
		<p>Une simple page HTML pour commencer</p>
	</div>
</header>
<main>
	<div class="container mt-4">
		<div class="row">
            <?php foreach ($productList->products as $product) { ?>
				<div class="col-md-4 mb-4"> <!-- Chaque carte occupe 1/3 de la ligne sur un écran moyen -->
					<div class="card" style="width: 100%;"> <!-- Ajustement pour s'adapter à la colonne -->
						<img src="<?php echo $product->getPhoto(); ?>" class="card-img-top" alt="<?php echo $product->getName(); ?>">
						<div class="card-body">
							<h5 class="card-title"><?php echo $product->getName(); ?></h5>
							<p class="card-text">Price: <?php echo $product->getPrice(); ?> €</p>
							<a href="/shop/product.php?user=<?php echo $currentUser; ?>&product=<?php echo $product->getId(); ?>" class="btn btn-primary">Buy</a>
						</div>
					</div>
				</div>
            <?php } ?>
		</div>
	</div>
</main>

<footer class="text-center mt-4">
	<p>&copy; 2024 Votre Nom</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
		crossorigin="anonymous"></script>
</body>
</html>
