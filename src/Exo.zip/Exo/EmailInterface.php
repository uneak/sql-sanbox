<?php

    namespace App\Exo;

    interface EmailInterface
    {
        public function getEmail(): string;
    }