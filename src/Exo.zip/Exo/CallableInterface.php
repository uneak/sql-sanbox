<?php

    namespace App\Exo;

    interface CallableInterface
    {
        public function getTelephone(): string;
    }