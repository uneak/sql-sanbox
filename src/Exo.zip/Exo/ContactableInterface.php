<?php

    namespace App\Exo;

    interface ContactableInterface
    {
        public function getNom(): string;
        public function getPrenom(): string;
    }