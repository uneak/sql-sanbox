<?php

    require __DIR__ . '/../vendor/autoload.php';

    use App\Singleton\DatabaseConnection;

    $database = new DatabaseConnection();
    $conn = $database->getConnection();

    try {
        // Exécuter une requête de sélection simple
        $query = $conn->query(
            'SELECT * FROM Users'
        );


        $results = $query->fetchAll(PDO::FETCH_ASSOC);

        // Début du tableau HTML
        echo "<table border='1' cellpadding='10' cellspacing='0'>";
        echo "<thead>";
        echo "<tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Photo</th>
            <th>User Role</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Password</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Updated At</th>
          </tr>";
        echo "</thead>";
        echo "<tbody>";

        // Afficher chaque ligne de résultat sous forme de ligne de tableau
        foreach ($results as $row) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['first_name'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['last_name'] ?? '') . "</td>";
            echo "<td><img src='" . htmlspecialchars($row['photo'] ?? '') . "' alt='Photo' width='50'></td>";
            echo "<td>" . htmlspecialchars($row['user_role'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['phone'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['email'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['password'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['status'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['created_at'] ?? '') . "</td>";
            echo "<td>" . htmlspecialchars($row['updated_at'] ?? '') . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";

    } catch (PDOException $e) {
        echo "Erreur lors de l'exécution de la requête : " . $e->getMessage();
    }

